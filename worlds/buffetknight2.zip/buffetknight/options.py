from dataclasses import dataclass

from Options import Choice, OptionGroup, PerGameCommonOptions, Range, Toggle


class HardMode(Toggle):
    """
    Hard mode text
    """
    display_name = "Hard Mode"


class Goal(Choice):
    """
    Choice Text
    """
    display_name = "Victory Condition"

    option_default = 0
    option_fullcourse = 1
    option_other = 2

    default = option_default

class IncludeSecret(Toggle):
    """
    Option to include Secret Dungeon when placing key items.
    """
    display_name = "Include Secret Dungeon"
    
    default = 1



@dataclass
class BKOptions(PerGameCommonOptions):
    hard_mode: HardMode
    goal: Goal
    include_secret: IncludeSecret


# If we want to group our options by similar type, we can do so as well. This looks nice on the website.
option_groups = [
    OptionGroup(
        "Gameplay Options",
        [HardMode, Goal],
    ),
]

option_presets = {
    "Option Preset A": {
        "hard_mode": False,
    },
    "Option Preset B": {
        "hard_mode": True,
    },
}
