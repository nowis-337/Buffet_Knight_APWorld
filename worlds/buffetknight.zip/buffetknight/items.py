from __future__ import annotations

from typing import TYPE_CHECKING

from BaseClasses import Item, ItemClassification

if TYPE_CHECKING:
    from .world import BKWorld

ITEM_NAME_TO_ID = {
    "Heartful Fruit": 1,
    "Chilli Bomb": 2,
    "Chitin Shell": 3,
    "Bouncy Gum": 4,
    "Lemon Shock": 5,
    "Witch's Brew": 6,
    "Ambrosial Herb": 7,
    "Fiery Pepper": 8,
    "Celestial Sugar": 9,
    "M.S.G.": 10,
    "Abyssal Salt": 11,
    "Iron Knife": 12,
    "Stainless Steel Knife":13,
    "Ultimaxcalibur(TM)": 14,
    #"Forbidden Insight": 15,
    "Mysterious Fried Chicken": 16,
    "Mineral Ore 1": 17,
    "Mineral Ore 2": 18,
    "Mineral Ore 3": 19,
    "Mineral Ore 4": 20,
    "Mineral Ore 5": 21,
    "Mineral Ore 6": 22,
    "Mineral Ore 7": 23,
    "Mineral Ore 8": 24,
    "Mineral Ore 9": 25,
    "Temple Key 1": 26,
    "Temple Key 2": 27,
    "Storage Key": 28,
    #"Prison Key": 29, #FIXED
    "Tower Master Key": 30,
    "Factory Key": 31,
    "Fruitful Essence": 32,
    "Molten Essence": 33,
    "Voltaic Essence": 34,
    "Bubble Gum Essence": 35,
    "Ocean Essence": 36,
    "Gastronomancy Essence": 37,
    #"Gastronomancy Potion": 38, #FIXED
    "Red Juicy Tomato": 39,
    "Meat Effigy": 40,
    "Sanctuary Pass": 41,
    "Bag of Crunchy Chips": 42,
    "Brulee Wing Toy 1": 43,
    #"Brulee Wing Toy 2": 44, #UNUSED
    "Mixer Tank Toy": 45,
    "Note in a Bottle": 46,
    "Jolly Meal Delivery": 47,
    "Stinky Berry": 48,
    "Fruitful Potion": 49,
    "Molten Potion": 50,
    "Bubble Gum Potion": 51,
    "Voltaic Potion": 52,
    "Oceanic Potion": 53,
    "Peashooter": 54,
    "Shish-Kebab": 55,
    "Seasoning Splash": 56,
    "Iron Helmet": 57,
    "Stainless Steel Helmet": 58,
    "Royal Helmet": 59,
    "Heart Upgrade 1": 60,
    "Heart Upgrade 2": 61,
    "Heart Upgrade 3": 62,
    "Heart Upgrade 4": 63,
    "Stomach Upgrade 1": 64,
    "Stomach Upgrade 2": 65,
    "Stomach Upgrade 3": 66,
    "Stomach Upgrade 4": 67,
    "Item Pouch 1": 68,
    "Item Pouch 2": 69,
    "Item Pouch 3": 70,
    "Relic Fragment 1": 71,
    "Relic Fragment 2": 72,
    "Relic Fragment 3": 73,
    "Relic Fragment 4": 74,
    "Relic Fragment 5": 75,
    "Relic Fragment 6": 76,
    "Emergency Snack": 77,
    "Chocolate Coin": 78,
    "Jumbo Plate": 79,
    "Kitty Coffee": 80,
    "Double-Ended Spork": 81,
    "Extra Credit": 82,
    "Golden Apple": 83,
    "Antacids": 84,
    "Nimble Net": 85,
    "Throat Lozenge": 86,
    "Garlic Breath": 87,
    "Goblin Totem": 88,
    "Reaper's Meal Ticket": 89,
    "Zen Lotus Root": 90,
    "Dietary Supplement": 91,
    "Gourmet Shard 1": 92,
    "Gourmet Shard 2": 93,
    "Gourmet Shard 3": 94,
    "Gourmet Shard 4": 95,
    "Gourmet Shard 5": 96,
    "Gourmet Crystal 1": 97,
    "Gourmet Crystal 2": 98,
    "Gourmet Crystal 3": 99,
    "Gourmet Crystal 4": 100,
    "Large Gourmet Crystal 1": 101,
    "Large Gourmet Crystal 2": 102,
    "Large Gourmet Crystal 3": 103,
    "Large Gourmet Crystal 4": 104,
    "Large Gourmet Crystal 5": 105,
    "Deluxe Gourmet Crystal 1": 106,
    "Deluxe Gourmet Crystal 2": 107,
    "Deluxe Gourmet Crystal 3": 108,
    "Deluxe Gourmet Crystal 4": 109,
    "Gold 1": 110,
    "Gold 2": 111,
    "Gold 3": 112,
    "Gold 4": 113,
    "Gold 5": 114,
    "Gold 6": 115,
    "Gold 7": 116,
    "Gold 8": 117,
    "Gold 9": 118,
    "Gold 10": 119,
    "Gold 11": 120,
    "Gold 12": 121,
    "Gold 13": 122,
    "Gold 14": 123,
    "Gold 15": 124,
    "Gold 16": 125,
    "Gold 17": 126,
    "Gold 18": 127,
    "Gold 19": 128,
}

DEFAULT_ITEM_CLASSIFICATIONS = {
    "Heartful Fruit": ItemClassification.progression | ItemClassification.useful,
    "Chilli Bomb": ItemClassification.progression | ItemClassification.useful,
    "Chitin Shell": ItemClassification.progression | ItemClassification.useful,
    "Bouncy Gum": ItemClassification.progression | ItemClassification.useful,
    "Lemon Shock": ItemClassification.progression | ItemClassification.useful,
    "Witch's Brew": ItemClassification.progression | ItemClassification.useful,
    "Ambrosial Herb": ItemClassification.progression,
    "Fiery Pepper": ItemClassification.progression,
    "Celestial Sugar": ItemClassification.progression,
    "M.S.G.": ItemClassification.progression,
    "Abyssal Salt": ItemClassification.progression,
    "Iron Knife":  ItemClassification.useful,
    "Stainless Steel Knife": ItemClassification.progression | ItemClassification.useful,
    "Ultimaxcalibur(TM)": ItemClassification.useful,
    #"Forbidden Insight": ItemClassification.progression, #FIXED ITEM
    "Mysterious Fried Chicken": ItemClassification.progression,
    "Mineral Ore 1": ItemClassification.progression,
    "Mineral Ore 2": ItemClassification.progression,
    "Mineral Ore 3": ItemClassification.progression,
    "Mineral Ore 4": ItemClassification.progression,
    "Mineral Ore 5": ItemClassification.progression,
    "Mineral Ore 6": ItemClassification.progression,
    "Mineral Ore 7": ItemClassification.progression,
    "Mineral Ore 8": ItemClassification.progression,
    "Mineral Ore 9": ItemClassification.progression,
    "Temple Key 1": ItemClassification.progression,
    "Temple Key 2": ItemClassification.progression,
    "Storage Key": ItemClassification.progression,
    "Prison Key": ItemClassification.progression,
    "Tower Master Key": ItemClassification.progression,
    "Factory Key": ItemClassification.progression,
    "Fruitful Essence": ItemClassification.progression,
    "Molten Essence": ItemClassification.progression,
    "Voltaic Essence": ItemClassification.progression,
    "Bubble Gum Essence": ItemClassification.progression,
    "Ocean Essence": ItemClassification.progression,
    "Gastronomancy Essence": ItemClassification.progression,
    #"Gastronomancy Potion": ItemClassification.progression, #FIXED ITEM
    "Red Juicy Tomato": ItemClassification.progression,
    "Meat Effigy": ItemClassification.progression,
    "Sanctuary Pass": ItemClassification.useful,
    "Bag of Crunchy Chips": ItemClassification.progression,
    "Brulee Wing Toy 1": ItemClassification.useful,
    #"Brulee Wing Toy 2": ItemClassification.useful, #UNUSED ITEM
    "Mixer Tank Toy": ItemClassification.useful,
    "Note in a Bottle": ItemClassification.progression,
    "Jolly Meal Delivery": ItemClassification.progression,
    "Stinky Berry": ItemClassification.progression,
    "Fruitful Potion": ItemClassification.progression,
    "Molten Potion": ItemClassification.progression,
    "Bubble Gum Potion": ItemClassification.progression,
    "Voltaic Potion": ItemClassification.progression,
    "Oceanic Potion": ItemClassification.progression,
    "Peashooter": ItemClassification.useful,
    "Shish-Kebab": ItemClassification.useful,
    "Seasoning Splash": ItemClassification.useful,
    "Iron Helmet": ItemClassification.useful,
    "Stainless Steel Helmet": ItemClassification.useful,
    "Royal Helmet": ItemClassification.useful,
    "Heart Upgrade 1": ItemClassification.useful,
    "Heart Upgrade 2": ItemClassification.useful,
    "Heart Upgrade 3": ItemClassification.useful,
    "Heart Upgrade 4": ItemClassification.useful,
    "Stomach Upgrade 1": ItemClassification.useful,
    "Stomach Upgrade 2": ItemClassification.useful,
    "Stomach Upgrade 3": ItemClassification.useful,
    "Stomach Upgrade 4": ItemClassification.useful,
    "Item Pouch 1": ItemClassification.useful,
    "Item Pouch 2": ItemClassification.useful,
    "Item Pouch 3": ItemClassification.useful,
    "Relic Fragment 1": ItemClassification.progression,
    "Relic Fragment 2": ItemClassification.progression,
    "Relic Fragment 3": ItemClassification.progression,
    "Relic Fragment 4": ItemClassification.progression,
    "Relic Fragment 5": ItemClassification.progression,
    "Relic Fragment 6": ItemClassification.progression,
    "Emergency Snack": ItemClassification.useful,
    "Chocolate Coin": ItemClassification.useful,
    "Jumbo Plate": ItemClassification.useful,
    "Kitty Coffee": ItemClassification.useful,
    "Double-Ended Spork": ItemClassification.useful,
    "Extra Credit": ItemClassification.useful,
    "Golden Apple": ItemClassification.useful,
    "Antacids": ItemClassification.useful,
    "Nimble Net": ItemClassification.useful,
    "Throat Lozenge": ItemClassification.useful,
    "Garlic Breath": ItemClassification.useful,
    "Goblin Totem": ItemClassification.useful,
    "Reaper's Meal Ticket": ItemClassification.useful,
    "Zen Lotus Root": ItemClassification.useful,
    "Dietary Supplement": ItemClassification.useful,
    "Gourmet Shard 1": ItemClassification.filler,
    "Gourmet Shard 2": ItemClassification.filler,
    "Gourmet Shard 3": ItemClassification.filler,
    "Gourmet Shard 4": ItemClassification.filler,
    "Gourmet Shard 5": ItemClassification.filler,
    "Gourmet Crystal 1": ItemClassification.filler,
    "Gourmet Crystal 2": ItemClassification.filler,
    "Gourmet Crystal 3": ItemClassification.filler,
    "Gourmet Crystal 4": ItemClassification.filler,
    "Large Gourmet Crystal 1": ItemClassification.filler,
    "Large Gourmet Crystal 2": ItemClassification.filler,
    "Large Gourmet Crystal 3": ItemClassification.filler,
    "Large Gourmet Crystal 4": ItemClassification.filler,
    "Large Gourmet Crystal 5": ItemClassification.filler,
    "Deluxe Gourmet Crystal 1": ItemClassification.filler,
    "Deluxe Gourmet Crystal 2": ItemClassification.filler,
    "Deluxe Gourmet Crystal 3": ItemClassification.filler,
    "Deluxe Gourmet Crystal 4": ItemClassification.filler,
    "Gold 1": ItemClassification.filler,
    "Gold 2": ItemClassification.filler,
    "Gold 3": ItemClassification.filler,
    "Gold 4": ItemClassification.filler,
    "Gold 5": ItemClassification.filler,
    "Gold 6": ItemClassification.filler,
    "Gold 7": ItemClassification.filler,
    "Gold 8": ItemClassification.filler,
    "Gold 9": ItemClassification.filler,
    "Gold 10": ItemClassification.filler,
    "Gold 11": ItemClassification.filler,
    "Gold 12": ItemClassification.filler,
    "Gold 13": ItemClassification.filler,
    "Gold 14": ItemClassification.filler,
    "Gold 15": ItemClassification.filler,
    "Gold 16": ItemClassification.filler,
    "Gold 17": ItemClassification.filler,
    "Gold 18": ItemClassification.filler,
    "Gold 19": ItemClassification.filler,

}

item_filler_list = []

class BKItem(Item):
    game = "Buffet Knight"


def get_random_filler_item_name(world: BKWorld) -> str:
    # #Trap Items Later?
    # if len(item_filler_list) == 0:
    #     # If run out of filler items, recreate list and pick from random again
    #     create_filler_item_list()
    randomIndex = world.random.randint(0, len(item_filler_list) - 1)
    return item_filler_list[randomIndex]
    return item_filler_list.pop(randomIndex)


def create_item_with_correct_classification(world: BKWorld, name: str) -> BKItem:
    classification = DEFAULT_ITEM_CLASSIFICATIONS[name]
    return BKItem(name, classification, ITEM_NAME_TO_ID[name], world.player)

def create_filler_item_list() -> None:
    item_filler_list.clear()
    for key, value in DEFAULT_ITEM_CLASSIFICATIONS.items():
        if value == ItemClassification.filler:
            item_filler_list.append(key)
    


# With those two helper functions defined, let's now get to actually creating and submitting our itempool.
def create_all_items(world: BKWorld) -> None:

    itempool: list[Item] = []
 
    for key in ITEM_NAME_TO_ID.keys():
        item: Item = world.create_item(key)
        itempool.append(item)

    number_of_items = len(itempool)
    create_filler_item_list()

    #Fillers
    number_of_unfilled_locations = len(world.multiworld.get_unfilled_locations(world.player))
    needed_number_of_filler_items = number_of_unfilled_locations - number_of_items
    itempool += [world.create_filler() for _ in range(needed_number_of_filler_items)]
    world.multiworld.itempool += itempool

